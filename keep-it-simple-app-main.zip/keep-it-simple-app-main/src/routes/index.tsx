import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  ArrowLeft, Bell, Car, Check, ChevronRight, CircleDollarSign, Clock3,
  CreditCard, Home, LocateFixed, LockKeyhole, MapPin, Menu, MessageCircle,
  Navigation, Phone, Search, Shield, Star, UserRound, UsersRound, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import splashImage from "@/assets/references/01-splash.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "TAXI 360 — Huauchinango" },
    { name: "description", content: "Pide un taxi seguro en Huauchinango." },
    { property: "og:title", content: "TAXI 360 — Huauchinango" },
    { property: "og:description", content: "Pide un taxi seguro en Huauchinango." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ]}),
  component: TaxiApp,
});

type Screen = "splash" | "login" | "map" | "search" | "service" | "finding" | "confirmed" | "security" | "arrived" | "profile";

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className={compact ? "brand compact" : "brand"}><span>TAXI</span><b>360</b><i /></div>;
}

function StatusBar({ light = true }: { light?: boolean }) {
  return <div className={`status ${light ? "light" : "dark"}`}><b>9:41</b><span>▮▮▮ ◇ ▰</span></div>;
}

function MapCanvas({ route = false }: { route?: boolean }) {
  return <div className="map-canvas" aria-hidden="true">
    <i className="road r1" /><i className="road r2" /><i className="road r3" /><i className="road r4" /><i className="road r5" />
    <span className="map-place p1">Huauchinango</span><span className="map-place p2">Centro</span><span className="map-place p3">Mercado</span>
    {route && <div className="route-path" />}
    <div className="location-dot"><span /></div>
  </div>;
}

function IconButton({ label, children, onClick, className = "" }: { label: string; children: ReactNode; onClick?: () => void; className?: string }) {
  return <Button variant="ghost" size="icon" aria-label={label} className={`round-action ${className}`} onClick={onClick}>{children}</Button>;
}

function Back({ onClick }: { onClick: () => void }) {
  return <IconButton label="Regresar" onClick={onClick}><ArrowLeft /></IconButton>;
}

function BottomSheet({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`bottom-sheet ${className}`}><div className="sheet-handle" />{children}</section>;
}

function Primary({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return <Button variant="taxi" size="taxi" onClick={onClick}>{children}</Button>;
}

function AppFrame({ children, lightStatus = true, className = "" }: { children: ReactNode; lightStatus?: boolean; className?: string }) {
  return <div className={`mobile-frame ${className}`}><StatusBar light={lightStatus} />{children}<div className="home-indicator" /></div>;
}

function Splash({ next }: { next: () => void }) {
  return <AppFrame className="splash-screen">
    <img className="splash-photo" src={splashImage.url} alt="Calle tradicional de Huauchinango" />
    <div className="splash-overlay" />
    <div className="splash-brand"><Logo /><h1>Huauchinango</h1><p>siempre en movimiento</p></div>
    <Primary onClick={next}>Comenzar</Primary>
  </AppFrame>;
}

function Login({ next }: { next: () => void }) {
  return <AppFrame className="content-screen login-screen">
    <div className="login-logo"><Logo compact /></div>
    <header className="screen-heading"><h1>Bienvenido</h1><p>Ingresa para continuar</p></header>
    <div className="form-stack">
      <label>Correo electrónico<input type="email" placeholder="nombre@correo.com" /></label>
      <label>Contraseña<input type="password" placeholder="••••••••" /></label>
      <button className="text-link">¿Olvidaste tu contraseña?</button>
    </div>
    <Primary onClick={next}>Iniciar sesión</Primary>
    <div className="divider"><span />o continúa con<span /></div>
    <div className="social-grid">
      <Button variant="outline" onClick={next}><b>G</b> Google</Button>
      <Button variant="outline" onClick={next}><b>●</b> Apple</Button>
    </div>
    <p className="account-copy">¿No tienes una cuenta? <b>Regístrate</b></p>
  </AppFrame>;
}

function MapHome({ goSearch, goProfile }: { goSearch: () => void; goProfile: () => void }) {
  return <AppFrame className="map-screen" lightStatus={false}>
    <MapCanvas />
    <div className="map-topbar"><IconButton label="Mi cuenta" onClick={goProfile}><Menu /></IconButton><Logo compact /><IconButton label="Notificaciones"><Bell /></IconButton></div>
    <IconButton label="Mi ubicación" className="locate-action"><LocateFixed /></IconButton>
    <BottomSheet>
      <div className="sheet-title"><div><small>BUENAS NOCHES</small><h1>¿A dónde vamos?</h1></div><span className="avatar-mini">AG</span></div>
      <Button variant="outline" className="destination-input" onClick={goSearch}><Search /><span>Buscar un destino</span><ChevronRight /></Button>
      <div className="quick-row"><button><Home /><span><b>Casa</b><small>Agregar dirección</small></span></button><button><Clock3 /><span><b>Recientes</b><small>Ver lugares</small></span></button></div>
    </BottomSheet>
  </AppFrame>;
}

const places = [
  ["Centro de Huauchinango", "Plaza de la Constitución"],
  ["Mercado Municipal", "Calle Hidalgo, Centro"],
  ["Hospital General", "Av. Revolución"],
  ["Terminal de Autobuses", "Carretera México–Tuxpan"],
];

function SearchScreen({ back, next }: { back: () => void; next: () => void }) {
  return <AppFrame className="content-screen search-screen">
    <header className="top-heading"><Back onClick={back} /><h1>Elige tu destino</h1></header>
    <div className="route-fields"><div><span className="origin-dot" /><input value="Mi ubicación actual" readOnly /></div><div><MapPin /><input autoFocus placeholder="¿A dónde vas?" /></div></div>
    <p className="section-label">DESTINOS SUGERIDOS</p>
    <div className="place-list">{places.map(([title, text], index) => <button key={title} onClick={next}><span className="place-icon">{index === 0 ? <Star /> : index === 3 ? <Car /> : <MapPin />}</span><span><b>{title}</b><small>{text}</small></span><ChevronRight /></button>)}</div>
  </AppFrame>;
}

const services = [
  { name: "Taxi 360 Eco", note: "3 min • Económico", price: "$48", icon: Car },
  { name: "Taxi 360 Plus", note: "5 min • Confort", price: "$65", icon: UsersRound },
];

function ServiceScreen({ back, next }: { back: () => void; next: () => void }) {
  const [selected, setSelected] = useState(0);
  return <AppFrame className="map-screen service-screen" lightStatus={false}>
    <MapCanvas route />
    <div className="floating-back"><Back onClick={back} /></div>
    <BottomSheet>
      <h1>Elige tu servicio</h1><p className="sheet-subtitle">Centro de Huauchinango</p>
      <div className="service-list">{services.map((item, index) => <button key={item.name} className={selected === index ? "active" : ""} onClick={() => setSelected(index)}><span className="car-icon"><item.icon /></span><span><b>{item.name}</b><small>{item.note}</small></span><strong>{item.price}</strong></button>)}</div>
      <div className="payment-row"><span><CreditCard />•••• 4242</span><button>Cambiar</button></div>
      <Primary onClick={next}>Solicitar TAXI 360</Primary>
    </BottomSheet>
  </AppFrame>;
}

function Finding({ cancel }: { cancel: () => void }) {
  return <AppFrame className="map-screen finding-screen" lightStatus={false}>
    <MapCanvas />
    <div className="search-radar"><span /><span /><span /><Car /></div>
    <BottomSheet><h1>Buscando tu taxi</h1><p>Conectando con conductores cercanos…</p><div className="progress"><i /></div><Button variant="outline" size="taxi" onClick={cancel}>Cancelar búsqueda</Button></BottomSheet>
  </AppFrame>;
}

function Confirmed({ safety, finish }: { safety: () => void; finish: () => void }) {
  return <AppFrame className="map-screen confirmed-screen" lightStatus={false}>
    <MapCanvas route />
    <div className="eta-card"><b>4 min</b><span>Tu taxi está en camino</span></div>
    <BottomSheet>
      <div className="driver-card"><span className="driver-avatar">LH</span><span><h2>Luis Hernández</h2><p><Star /> 4.9 · Taxi 360 Eco</p><small>Chevrolet Aveo · TX-4821</small></span></div>
      <div className="action-row"><IconButton label="Llamar"><Phone /></IconButton><IconButton label="Mensaje"><MessageCircle /></IconButton><IconButton label="Seguridad" onClick={safety}><Shield /></IconButton></div>
      <Primary onClick={finish}>Ver detalles del viaje</Primary>
    </BottomSheet>
  </AppFrame>;
}

function Security({ back }: { back: () => void }) {
  return <AppFrame className="content-screen security-screen">
    <header className="top-heading"><Back onClick={back} /><h1>Centro de seguridad</h1></header>
    <div className="safety-hero"><Shield /><h2>Tu viaje está protegido</h2><p>Estamos contigo durante todo el recorrido.</p></div>
    <div className="settings-list">
      <button><span><UsersRound /></span><div><b>Compartir mi viaje</b><small>Envía tu ubicación en tiempo real</small></div><ChevronRight /></button>
      <button><span><Phone /></span><div><b>Contactos de confianza</b><small>Administra tus contactos</small></div><ChevronRight /></button>
      <button><span><LockKeyhole /></span><div><b>Verificar viaje</b><small>Confirma los datos del conductor</small></div><ChevronRight /></button>
    </div>
    <Button variant="destructive" size="taxi" className="sos-button"><Phone /> Llamada de emergencia</Button>
  </AppFrame>;
}

function Arrived({ done }: { done: () => void }) {
  const [rating, setRating] = useState(0);
  return <AppFrame className="content-screen arrived-screen">
    <div className="success-mark"><Check /></div><header className="center-heading"><h1>¡Has llegado!</h1><p>Gracias por viajar con TAXI 360</p></header>
    <div className="receipt"><div><span>Total del viaje</span><strong>$48.00</strong></div><div><CreditCard /><span><b>Mastercard</b><small>•••• 4242</small></span><Check /></div></div>
    <section className="rating-box"><h2>¿Cómo estuvo tu viaje?</h2><p>Tu opinión nos ayuda a mejorar</p><div>{[1,2,3,4,5].map(n => <button key={n} aria-label={`${n} estrellas`} onClick={() => setRating(n)} className={rating >= n ? "rated" : ""}><Star /></button>)}</div><input placeholder="Cuéntanos más (opcional)" /></section>
    <Primary onClick={done}>Finalizar</Primary>
  </AppFrame>;
}

function Profile({ back, logout }: { back: () => void; logout: () => void }) {
  return <AppFrame className="content-screen profile-screen">
    <header className="top-heading"><Back onClick={back} /><h1>Mi cuenta</h1></header>
    <div className="profile-summary"><span className="profile-avatar">AG</span><div><h2>Ana García</h2><p>ana.garcia@email.com</p><small><Star /> 4.9 pasajera</small></div></div>
    <p className="section-label">CUENTA</p>
    <div className="settings-list compact-list"><button><span><UserRound /></span><div><b>Datos personales</b></div><ChevronRight /></button><button><span><CreditCard /></span><div><b>Métodos de pago</b></div><ChevronRight /></button><button><span><CircleDollarSign /></span><div><b>Historial de viajes</b></div><ChevronRight /></button><button><span><Shield /></span><div><b>Seguridad</b></div><ChevronRight /></button></div>
    <Button variant="outline" size="taxi" className="logout" onClick={logout}><X /> Cerrar sesión</Button>
  </AppFrame>;
}

function TaxiApp() {
  const [screen, setScreen] = useState<Screen>("splash");
  useEffect(() => { if (screen !== "finding") return; const timer = window.setTimeout(() => setScreen("confirmed"), 2600); return () => window.clearTimeout(timer); }, [screen]);
  const views: Record<Screen, ReactNode> = {
    splash: <Splash next={() => setScreen("login")} />, login: <Login next={() => setScreen("map")} />,
    map: <MapHome goSearch={() => setScreen("search")} goProfile={() => setScreen("profile")} />,
    search: <SearchScreen back={() => setScreen("map")} next={() => setScreen("service")} />,
    service: <ServiceScreen back={() => setScreen("search")} next={() => setScreen("finding")} />,
    finding: <Finding cancel={() => setScreen("service")} />,
    confirmed: <Confirmed safety={() => setScreen("security")} finish={() => setScreen("arrived")} />,
    security: <Security back={() => setScreen("confirmed")} />, arrived: <Arrived done={() => setScreen("map")} />,
    profile: <Profile back={() => setScreen("map")} logout={() => setScreen("login")} />,
  };
  return <main className="app-stage">{views[screen]}</main>;
}