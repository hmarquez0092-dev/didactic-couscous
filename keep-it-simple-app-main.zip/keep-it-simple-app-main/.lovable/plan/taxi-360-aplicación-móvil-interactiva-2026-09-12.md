# TAXI 360 — aplicación móvil interactiva

## Objetivo
Recrear la aplicación mostrada en las referencias, manteniendo su identidad visual oscura, detalles dorados, textos, destinos, servicios, conductor, seguridad, pago y perfil.

## Flujo
- Pantalla inicial con acceso a “Comenzar”.
- Inicio de sesión visual con correo, contraseña y accesos sociales.
- Mapa principal con búsqueda de destino, accesos guardados y menú de cuenta/seguridad.
- Selección de destino y tipo de taxi.
- Estados de búsqueda, taxi confirmado y llegada/pago.
- Pantallas de Centro de seguridad y Mi cuenta.
- Controles funcionales para avanzar, regresar, cancelar, valorar y navegar entre pantallas.

## Presentación
- Vista móvil optimizada, adaptable a pantallas mayores sin deformarse.
- Fondo azul petróleo casi negro, superficies elevadas, bordes azul gris y acentos dorados.
- Iconografía clara, coches y mapa recreados visualmente sin incrustar las capturas de referencia.
- Animaciones discretas en búsqueda, selección y cambios de pantalla.

## Detalles técnicos
- Implementación en una sola experiencia React con estado local para el prototipo interactivo.
- Componentes reutilizables para botones, filas, tarjetas de servicio y navegación.
- Metadatos propios de TAXI 360 y verificación visual en móvil y escritorio.
